from django.apps import AppConfig


class HpAppConfig(AppConfig):
    name = 'hp_app'
