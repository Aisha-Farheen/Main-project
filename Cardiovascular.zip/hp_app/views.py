from django.shortcuts import render
from .models import *

from django.views.decorators.cache import cache_control
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.core import serializers
import json
from django.core.files.storage import FileSystemStorage
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


from datetime import datetime
from django.views.decorators.csrf import ensure_csrf_cookie
import pickle
model = pickle.load(open("RFCmodel.pkl", "rb"))
import paho.mqtt.client as paho
import paho.mqtt.client as mqtt
datas=""



def on_subscribe(client, userdata, mid, granted_qos):
        print("Subscribed: "+str(mid)+" "+str(granted_qos))

def on_message(client, userdata, msg):
    global datas,templist,hrlist,fsts,timelist
    datas=msg.payload.decode("utf-8")
    print(datas)
    
    
    print(msg.topic+" "+str(msg.qos)+" "+str(msg.payload))
client = paho.Client()
client.on_subscribe = on_subscribe
client.on_message = on_message
client.connect("broker.hivemq.com", 1883)
client.subscribe("smartheart", qos=1)
client.loop_start()
# Create your views here.


def display_login(request):
    return render(request, 'login.html', {})


def admin1(request):
    return render(request, 'home_admin.html', {})


def show_register(request):
    return render(request, 'register.html', {})


def view_users_admin(request):
    ob = Patients_table.objects.all()
    return render(request, 'view_users_admin.html', {"data": ob})


def manage_users_admin(request):
    return render(request, 'manage_users_admin.html', {})


def user(request):
    return render(request, 'home_user.html', {})


def doctor_home(request):
    return render(request, 'home_doctor.html', {})


def Reg_doctor(request):
    return render(request, 'Doctor_reg.html', {})


def Add_product(request):
    return render(request, 'admin_add_product.html', {})


def Prediction(request):
    hrate=datas
    return render(request, 'prediction.html', {"hrate":hrate})


def View_product(request):
    return render(request, 'admin_view_product.html', {})


def view_doctors_admin(request):
    ob = Doctor_table.objects.all()
    return render(request, 'view_doctors_admin.html', {"data": ob})


def view_doctors_user(request):
    ob = Doctor_table.objects.all()
    return render(request, 'user_view_doctors.html', {"data": ob})


def Userlistproduct(request):
    data = Product_table.objects.all()
    return render(request, 'user_view_product.html', {'data': data})


def Doctor_list_pats(request):
    ob = Patients_table.objects.all()
    return render(request, 'doctor_view_users.html', {"data": ob})


def check_login(request):
    var1 = request.GET.get("uname")
    var2 = request.GET.get("password")
    utyp = request.GET.get("utyp")
    print(var1, var2, utyp)
    data = {}
    if(utyp == "doc"):
        try:
            Doctor_table.objects.get(username=var1, password=var2)
            request.session["username"] = var1
            data["msg"] = "doc"
            print("login")
            return JsonResponse(data, safe=False)
        except:
            data["msg"] = "no"
            return JsonResponse(data, safe=False)
    else:
        try:
            Patients_table.objects.get(username=var1, password=var2)
            request.session["username"] = var1
            data["msg"] = "pat"
            print("login")
            return JsonResponse(data, safe=False)
        except:
            data["msg"] = "no"
            return JsonResponse(data, safe=False)


def register(request):
    name = request.GET.get("name")
    email = request.GET.get("email")
    age = request.GET.get("age")
    gender = request.GET.get("gender")
    phone = request.GET.get("phone")
    password = request.GET.get("password")
    username = request.GET.get("username")
    try:
        ob = Patients_table(name=name, age=age, gender=gender, email=email,
                            phone=phone, username=username, password=password)

        ob.save()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except:

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def doctor_reg(request):
    print("yes")
    name = request.GET.get("name")
    email = request.GET.get("email")
    place = request.GET.get("place")
    phone = request.GET.get("phone")
    password = request.GET.get("password")
    username = request.GET.get("username")
    print(name, email, place, phone, password, username)
    try:
        ob = Doctor_table(name=name, place=place, email=email,
                          phone=phone, username=username, password=password)

        ob.save()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def edit_doctor(request):
    uid = request.GET.get("uid")
    name = request.GET.get("name")
    email = request.GET.get("email")
    place = request.GET.get("place")

    phone = request.GET.get("phone")
    password = request.GET.get("password")
    username = request.GET.get("username")
    print("userid==", uid)
    try:
        ob = Doctor_table.objects.get(id=int(uid))
        ob.name = name
        ob.place = place
        ob.email = email
        ob.phone = phone
        ob.username = username
        ob.password = password

        ob.save()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def edit_patient(request):
    uid = request.GET.get("uid")
    name = request.GET.get("name")
    email = request.GET.get("email")
    age = request.GET.get("age")
    gender = request.GET.get("gender")
    phone = request.GET.get("phone")
    password = request.GET.get("password")
    username = request.GET.get("username")
    print("userid==", uid)
    try:
        ob = Patients_table.objects.get(id=int(uid))
        ob.name = name
        ob.age = age
        ob.gender = gender
        ob.email = email
        ob.phone = phone
        ob.username = username
        ob.password = password

        ob.save()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def deletepatient(request):
    uid = request.GET.get("uid")

    print("userid==", uid)
    try:
        ob = Patients_table.objects.get(id=int(uid))

        ob.delete()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def deletedoctor(request):
    uid = request.GET.get("uid")

    print("userid==", uid)
    try:
        ob = Doctor_table.objects.get(id=int(uid))

        ob.delete()
        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


@ensure_csrf_cookie
def upload_item(request):

    data = {}
    if request.method == "GET":
        return render(request, 'Shophome.html', )
    if request.method == 'POST':
        files = request.FILES.getlist('files[]', None)
        pname = request.POST.get("pname")
        brand = request.POST.get("brand")
        price = request.POST.get("price")
        info = request.POST.get("info")
        stck = request.POST.get("stck")

        print(pname+brand+price+info+stck)
        now = datetime.now()
        dt_string = now.strftime("%d_%m_%Y_%H_%M_%S")
        dt_string = str(dt_string)+".jpg"

        # Product_name=pname,Brand=brand,Price=price,Info=info,Stock=stck,Img_path=dt_string

        try:
            ob = Product_table.objects.get(Product_name=pname, Brand=brand)
            data["msg"] = "exist"

            return JsonResponse(data, safe=False)
        except:
            for f in files:
                handle_uploaded_file(f, dt_string)
            ob = Product_table(Product_name=pname, Brand=brand,
                               Price=price, Info=info, Stock=stck, Img_path=dt_string)
            ob.save()
            data["msg"] = "yes"
            print(data)
            return JsonResponse(data, safe=False)


def handle_uploaded_file(f, name):
    print(name)
    filename = 'F:/Project 2021-22/Cardiovascular/hp_app/static/images/' + \
        str(name)
    with open(filename, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)


def Get_products(request):

    ob = Product_table.objects.all()
    datalist = []
    for i in ob:
        data = {}
        data["pid"] = i.id
        data["name"] = i.Product_name
        data["brand"] = i.Brand

        data["price"] = i.Price
        data["info"] = i.Info
        data["stock"] = i.Stock

        datalist.append(data)
    print("data")
    return JsonResponse(datalist, safe=False)


@ensure_csrf_cookie
def update_item(request):

    data = {}
    if request.method == "GET":
        return render(request, 'Shophome.html', )
    if request.method == 'POST':
        files = request.FILES.getlist('files[]', None)
        print("length of file==>", len(files))
        pname = request.POST.get("pname")
        pid = request.POST.get("pid")
        brand = request.POST.get("brand")
        price = request.POST.get("price")
        info = request.POST.get("info")
        stck = request.POST.get("stck")
        now = datetime.now()
        print("brand", price)

        dt_string = now.strftime("%d_%m_%Y_%H_%M_%S")
        dt_string = str(dt_string)+".jpg"

        k = False
        ob = Product_table.objects.filter(Product_name=pname)
        pidlist = []
        for i in ob:
            prid = i.id
            if(int(pid) != prid):
                k = True
            print(prid)

        if(k):
            data["msg"] = "exist"
        else:
            ob1 = Product_table.objects.get(id=int(pid))
            if(len(files) == 0):

                ob1.Product_name = pname
                ob1.Brand = brand
                ob1.Price = price
                ob1.Info = info

                ob1.Stock = stck
                ob1.save()
                data["msg"] = "yes"
            else:
                for f in files:
                    handle_uploaded_file(f, dt_string)
                ob1.Product_name = pname
                ob1.Brand = brand

                ob1.Price = price
                ob1.Info = info

                ob1.Stock = stck
                ob1.Img_path = dt_string
                ob1.save()
                data["msg"] = "yes"

        return JsonResponse(data, safe=False)

    else:
        data["msg"] = "error"
        print(data)
        return JsonResponse(data, safe=False)


def delete_product(request):
    pid = request.GET.get("uid")
    ob = Product_table.objects.get(id=int(pid))
    ob.delete()
    data = {"status": 0}
    return JsonResponse(data, safe=False)


def check_heart(request):
    hdata = request.GET.get("hdata")

    try:
        print("hdata", hdata)
        hlist = hdata.split(",")
        feats = [float(x) for x in hlist]
        ytest = [feats]
        ypred = model.predict(ytest)
        print(ypred)
        if(ypred[0] == 0):
            res = "Normal Condition"
        else:
            res = "Presence of heart disease,Please consult a doctor immediately"
        data = {"status": res}
        print("result", res)
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def selectuser2(request):
    uid = request.GET.get("uid")
    utyp = request.GET.get("utyp")

    print("userid==", uid)

    print("utyp==", utyp)
    try:
        if(utyp == 'doc'):
            ob = Doctor_table.objects.get(id=int(uid))
            unm = ob.username
            request.session["user2"] = unm
        else:
            ob = Patients_table.objects.get(id=int(uid))
            unm = ob.username
            request.session["user2"] = unm

        data = {"status": 1}
        return JsonResponse(data, safe=False)
    except Exception as e:
        print(e)

        data = {"status": 0}
        return JsonResponse(data, safe=False)


def Chatpage(request):
    return render(request, 'Chatpage.html', {})


def Getallchats(request):
    sndr = request.session["username"]
    rcvr = request.session["user2"]

    ob = Chat_table.objects.filter(
        From=sndr, To=rcvr) | Chat_table.objects.filter(From=rcvr, To=sndr)
    mylist = []
    for i in ob:
        li1 = []
        if(i.From == sndr):
            li1.append("You")
        else:
            li1.append(rcvr)
        li1.append(i.chat)
        mylist.append(li1)
    print(mylist)

    resp = {}
    resp["datalist"] = mylist
    return JsonResponse(resp, safe=False)


def Addchat(request):
    msg = request.GET.get("qstn")
    sndr = request.session["username"]
    rcvr = request.session["user2"]
    ob = Chat_table(From=sndr, To=rcvr, chat=msg)
    ob.save()
    data = {"msg": "yes"}

    return JsonResponse(data, safe=False)


def addtocart(request):
    itemid = request.POST.get("idno")
    count = request.POST.get("count")

    ob0 = Product_table.objects.get(id=int(itemid))
    pname = ob0.Product_name
    price = ob0.Price
    stock = ob0.Stock
    uname = request.session["username"]
    print(itemid+pname+price+uname+stock)
    try:
        count = int(count)
        stock = int(stock)
        if(count > stock):
            return HttpResponse("<script>alert('Stock exceed!!');window.location.href='/Userlistproduct/'</script>")
        else:
            try:
                ob = Cart_table.objects.get(Username=uname, Product_name=pname)
                return HttpResponse("<script>alert('Item already added!!');window.location.href='/Userlistproduct/'</script>")
            except:
                price = int(price)
                total = price*count
                ob = Cart_table(Username=uname, Product_name=pname,Price=price, Count=count, Total=total)
                ob.save()
                return HttpResponse("<script>alert('Item added to cart!!');window.location.href='/Userlistproduct/'</script>")

    except:
        return HttpResponse("<script>alert('Pleade add a count as digits!!');window.location.href='/Userlistproduct/'</script>")



def Cart_page(request):
    print("cartpage")
   
    uname=request.session["username"]
    data=Cart_table.objects.filter(Username=uname)
    total=0
    for i in data:
        total=total+int(i.Price)
    print("total==>",total)
    return render(request,'user_view_cart.html',{'data':data,'total':total})

def payment_page(request):
    
    uname=request.session["username"]
    data=Cart_table.objects.filter(Username=uname)
    total=0
    for i in data:
        total=total+int(i.Price)
    print("total==>",total)
    return render(request,'payment.html',{'total':total})





def delete_cart(request):
    pid=request.GET.get("qid")
    ob=Cart_table.objects.get(id=int(pid))
    ob.delete()
    data={"status":0}
    return JsonResponse(data,safe=False)


def buy_product(request):

    uname=request.session["username"]
    pdct=""
    count=""
    prc=""
    data=Cart_table.objects.filter(Username=uname)
    total=0
    for i in data:
        pdct=i.Product_name+","+pdct
        count=i.Count+","+count
        prc=i.Price+","+prc
        total=total+int(i.Price)
    print(pdct)
    print(count)
    print(prc)
    print("total==>",total)
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y")
    ob1=Purchase_table(username=uname,items=pdct[:-1],count=count[:-1],price=prc[:-1],total=total,date=dt_string)
    ob1.save()

    for i in data:
        i.delete()
    resp={"msg":0}
    return JsonResponse(resp,safe=False)

def User_myorders(request):
    
    uname=request.session["username"]
    data=Purchase_table.objects.filter(username=uname)
    
    return render(request,'user_myorders.html',{'data':data})


def Admin_all_orders(request):
    
    data=Purchase_table.objects.all()
    
    return render(request,'admin_all_orders.html',{'data':data})



















def User_view(request):
    try:
        v1 = Patients_table.objects.all()
        print(v1, "d")
        data = {}
        if v1:
            valu = serializers.serialize("json", v1)
            data['d1'] = json.loads(valu)
            return JsonResponse(data, safe=False)
        else:
            return HttpResponse("no data")
    except Exception as e:
        print(e)
        return HttpResponse("error")


# def edit(request):
#     user_id = request.GET.get("id2")
#     user_name = request.GET.get("uname")
#     phone = request.GET.get("phone")

#     e = Users.objects.get(user_id=int(user_id))
#     e.user_name=user_name
#     e.phone = phone
#     e.save()

#     return HttpResponse("edited successfully")


def block(request):
    user_name = request.GET.get("uname")
    id2 = request.GET.get("id2")
    v = Users.objects.get(user_id=id2)
    v.flag = '1'
    v.save()
    return HttpResponse("successfully blocked")


def Block_un(request):
    user_name = request.GET.get("uname")
    id2 = request.GET.get("id2")
    v = Users.objects.get(user_id=id2)
    v.flag = '0'
    v.save()
    return HttpResponse("successfully unblocked")


def get_emotion_user(request):
    return render(request, "get_emotion_user.html", {})


def insert(request):
    image = request.POST.get("img")
    img = request.FILES["img"]
    fs = FileSystemStorage("hp_app\\static")
    fs.save(image, img)

    return render(request, 'get_emotion_user.html', {'image': img})


def get_emotion(request):
    path = request.GET.get("path")

    a = "hp_app/"
    final_path = a+path
    print(final_path)

    # analysing image using DeepFace
    face_analysis = DeepFace.analyze(img_path=final_path)
    # print("Face Analysis :",face_analysis)

    print("Emotion :", face_analysis["dominant_emotion"])
    my_emotion = face_analysis["dominant_emotion"]
    return HttpResponse(my_emotion)


def get_water_info(request):
    return render(request, 'get_water_info_user.html', {})


def consultant(request):
    return render(request, 'home_consultant.html', {})


def psychologist(request):
    return render(request, 'home_psychologist.html', {})


def Bot_response(request):
    qstn = request.GET.get("qstn")
    print(qstn)

    response = chatbot.get_response(qstn)
    print("bot-->", response)
    print(str(response))
    data = {"msg": str(response)}
    return JsonResponse(data, safe=False)


def surveypage(request):
    return render(request, 'survey.html', {})
