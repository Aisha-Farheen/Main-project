"""hp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from hp_app.views import *


urlpatterns = [
    url(r'admin/', admin.site.urls),

##################################
    url(r'^$',display_login),
    url(r'^show_register',show_register,name='show_register'),
    url(r'^register',register,name='register'),
    url(r'^display_login',display_login,name='display_login'),
    url(r'^check_login',check_login,name='check_login'),
########################################

###################################
    url(r'^view_users_admin',view_users_admin,name="view_users_admin"),
    url(r'^manage_users_admin',manage_users_admin,name="manage_users_admin"),
    url(r'^admin1',admin1,name='admin1'),
    url(r'^User_view',User_view,name='User_view'),
    # url(r'^edit',edit,name="edit"),
    url(r'^block',block,name='block'),
    url(r'^Block_un',Block_un,name='Block_un'),
    url(r'^Bot_response',Bot_response,name='Bot_response'),
    url(r'^Chatpage',Chatpage,name='Chatpage'),
    url(r'^surveypage',surveypage,name='surveypage'),
    url(r'^Addchat',Addchat,name='Addchat'),
    url(r'^Getallchats',Getallchats,name='Getallchats'),
##############################################

##############################
    url(r'^consultant',consultant,name="consultant"),

##############################

##############################
    url(r'^user',user,name='user'),
    url(r'^get_emotion_user',get_emotion_user,name="get_emotion_user"),
    url(r'^insert',insert,name="insert"),
    url(r'^get_emotion',get_emotion,name="get_emotion"),
    url(r'^get_water_info',get_water_info,name="get_water_info"),
######################################

##############################
    url(r'^psychologist',psychologist,name="psychologist"),
    url(r'^edit_patient',edit_patient,name="edit_patient"),
    url(r'^deletepatient',deletepatient,name="deletepatient"),
    url(r'^Reg_doctor',Reg_doctor,name="Reg_doctor"),
    url(r'^doctor_reg',doctor_reg,name="doctor_reg"),
    url(r'^view_doctors_admin',view_doctors_admin,name="view_doctors_admin"),
    url(r'^edit_doctor',edit_doctor,name="edit_doctor"),
    url(r'^deletedoctor',deletedoctor,name="deletedoctor"),
    url(r'^Add_product',Add_product,name="Add_product"),
    url(r'^upload_item',upload_item,name="upload_item"),
    url(r'^View_product',View_product,name="View_product"),
    url(r'^Get_products',Get_products,name="Get_products"),
    url(r'^update_item',update_item,name="update_item"),
    url(r'^delete_product',delete_product,name="delete_product"),
    url(r'^Prediction',Prediction,name="Prediction"),
    url(r'^check_heart',check_heart,name="check_heart"),
    url(r'^view_doctors_user',view_doctors_user,name="view_doctors_user"),
    url(r'^selectuser2',selectuser2,name="selectuser2"),
    url(r'^doctor_home',doctor_home,name="doctor_home"),
    url(r'^Doctor_list_pats',Doctor_list_pats,name="Doctor_list_pats"),
    url(r'^Userlistproduct',Userlistproduct,name="Userlistproduct"),
    url(r'^addtocart',addtocart,name="addtocart"),
    url(r'^Cart_page',Cart_page,name="Cart_page"),
    url(r'^payment_page',payment_page,name="payment_page"),
    url(r'^delete_cart',delete_cart,name="delete_cart"),
    url(r'^buy_product',buy_product,name="buy_product"),
    url(r'^User_myorders',User_myorders,name="User_myorders"),
    url(r'^Admin_all_orders',Admin_all_orders,name="Admin_all_orders"),
##############################
    ]
