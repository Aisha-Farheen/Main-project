# Importing libraries
import pandas as pd 
import numpy as np
from sklearn import metrics
import pickle
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier


# Reading data
df = pd.read_csv("heart.csv")
print(df.head(10))
feature_columns = ['age', 'sex', 'cp','trestbps', 'chol','fbs', 'restecg', 'thalach', 'exang' , 'oldpeak', 'slope', 'ca', 'thal']
predicted_class = ['target']

X = df[feature_columns]
y = df[predicted_class]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.30, random_state=10)


fill_values = SimpleImputer(missing_values=0, strategy="mean")

X_train = fill_values.fit_transform(X_train)
X_test = fill_values.fit_transform(X_test)

random_forest_model = RandomForestClassifier(random_state=10)

model = random_forest_model.fit(X_train, y_train)
pickle.dump(model,open("RFCmodel.pkl",'wb'))
Y_pred = model.predict(X_test)
acc_score=metrics.accuracy_score(y_test, Y_pred)


print("Accuracy = ",acc_score)