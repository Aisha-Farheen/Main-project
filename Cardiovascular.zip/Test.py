import pickle
model=pickle.load(open("RFCmodel.pkl","rb"))
ytest=[[34,0,1,118,210,0,1,192,0,0.7,2,0,2]]
ypred=model.predict(ytest)
print(ypred)